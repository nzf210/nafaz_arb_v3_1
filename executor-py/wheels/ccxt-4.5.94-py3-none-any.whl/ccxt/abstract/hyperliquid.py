from ccxt.base.types import Entry
_Dict = dict[str, object]
_List = list[object]


class ImplicitAPI:
    public_post_info = publicPostInfo = Entry[_Dict | _List | str]('info', ['public'], 'POST', {'cost': 10, 'byType': {'l2Book': 2, 'allMids': 2, 'clearinghouseState': 2, 'orderStatus': 2, 'spotClearinghouseState': 2, 'exchangeStatus': 2, 'candleSnapshot': 4}})
    private_post_exchange = privatePostExchange = Entry[_Dict]('exchange', ['private'], 'POST', {'cost': 1})
